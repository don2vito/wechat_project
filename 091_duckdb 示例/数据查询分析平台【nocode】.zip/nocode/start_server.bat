@echo off
echo ========================================
echo    Data Query Analysis Platform
echo    Starting Server and Opening Browser
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python 3.8 or higher
    pause
    exit /b 1
)

REM Check if required Python packages are installed
echo Checking Python dependencies...
pip show flask >nul 2>&1
if errorlevel 1 (
    echo Installing Flask...
    pip install flask
)

pip show pandas >nul 2>&1
if errorlevel 1 (
    echo Installing pandas...
    pip install pandas
)

pip show duckdb >nul 2>&1
if errorlevel 1 (
    echo Installing duckdb...
    pip install duckdb
)

pip show openpyxl >nul 2>&1
if errorlevel 1 (
    echo Installing openpyxl...
    pip install openpyxl
)

echo.
echo Starting backend server...
start /B python server.py

echo Waiting for server to start...
timeout /t 3 /nobreak >nul

echo Opening browser...
start http://localhost:5000

echo.
echo ========================================
echo Server started successfully!
echo Backend: http://localhost:5000
echo Frontend: http://localhost:5000
echo Press Ctrl+C to stop the server
echo ========================================

REM Keep the window open
pause
