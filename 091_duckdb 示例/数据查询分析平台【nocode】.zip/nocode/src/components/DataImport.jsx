import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, File, CheckCircle, XCircle, X } from 'lucide-react';
import { useData } from '../contexts/DataContext.jsx';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';

const DataImport = () => {
  const { addImportedFile, addTable } = useData();
  const [uploadProgress, setUploadProgress] = useState({});
  const [importedFiles, setImportedFiles] = useState([]);

  const processFile = async (file) => {
    const fileId = Date.now().toString();
    setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

    try {
      let data;
      const fileExtension = file.name.split('.').pop().toLowerCase();

      if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        data = await processExcelFile(file, fileId);
      } else if (fileExtension === 'csv') {
        data = await processCsvFile(file, fileId);
      } else if (fileExtension === 'txt') {
        data = await processTxtFile(file, fileId);
      } else {
        throw new Error('不支持的文件格式');
      }

      const tableData = {
        id: fileId,
        name: file.name.split('.')[0],
        data: data.rows,
        fields: data.fields,
        rowCount: data.rows.length,
        importTime: new Date().toISOString()
      };

      addTable(tableData);
      addImportedFile({
        id: fileId,
        name: file.name,
        size: file.size,
        type: file.type,
        status: 'success',
        importTime: new Date().toISOString()
      });

      setImportedFiles(prev => [...prev, {
        id: fileId,
        name: file.name,
        status: 'success',
        message: '导入成功'
      }]);

    } catch (error) {
      setImportedFiles(prev => [...prev, {
        id: fileId,
        name: file.name,
        status: 'error',
        message: error.message
      }]);
    } finally {
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[fileId];
        return newProgress;
      });
    }
  };

  const processExcelFile = (file, fileId) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          setUploadProgress(prev => ({ ...prev, [fileId]: 50 }));
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          
          if (jsonData.length === 0) {
            reject(new Error('文件为空'));
            return;
          }

          const headers = jsonData[0];
          const rows = jsonData.slice(1).map(row => {
            const obj = {};
            headers.forEach((header, index) => {
              obj[header] = row[index] || '';
            });
            return obj;
          });

          const fields = headers.map(header => ({
            name: header,
            type: inferDataType(rows.map(row => row[header]))
          }));

          setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
          resolve({ rows, fields });
        } catch (error) {
          reject(error);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  };

  const processCsvFile = (file, fileId) => {
    return new Promise((resolve, reject) => {
      setUploadProgress(prev => ({ ...prev, [fileId]: 30 }));
      Papa.parse(file, {
        header: true,
        complete: (results) => {
          setUploadProgress(prev => ({ ...prev, [fileId]: 80 }));
          if (results.errors.length > 0) {
            reject(new Error('CSV解析错误'));
            return;
          }

          const fields = Object.keys(results.data[0] || {}).map(key => ({
            name: key,
            type: inferDataType(results.data.map(row => row[key]))
          }));

          setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
          resolve({ rows: results.data, fields });
        },
        error: (error) => {
          reject(error);
        }
      });
    });
  };

  const processTxtFile = (file, fileId) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          setUploadProgress(prev => ({ ...prev, [fileId]: 50 }));
          const text = e.target.result;
          const lines = text.split('\n').filter(line => line.trim());
          
          if (lines.length === 0) {
            reject(new Error('文件为空'));
            return;
          }

          const headers = lines[0].split('\t');
          const rows = lines.slice(1).map(line => {
            const values = line.split('\t');
            const obj = {};
            headers.forEach((header, index) => {
              obj[header] = values[index] || '';
            });
            return obj;
          });

          const fields = headers.map(header => ({
            name: header,
            type: inferDataType(rows.map(row => row[header]))
          }));

          setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
          resolve({ rows, fields });
        } catch (error) {
          reject(error);
        }
      };
      reader.readAsText(file);
    });
  };

  const inferDataType = (values) => {
    const nonEmptyValues = values.filter(v => v !== null && v !== undefined && v !== '');
    
    if (nonEmptyValues.length === 0) return 'text';

    const numericCount = nonEmptyValues.filter(v => !isNaN(v) && !isNaN(parseFloat(v))).length;
    const dateCount = nonEmptyValues.filter(v => !isNaN(Date.parse(v))).length;

    if (numericCount / nonEmptyValues.length > 0.8) {
      return nonEmptyValues.some(v => String(v).includes('.')) ? 'float' : 'integer';
    }
    
    if (dateCount / nonEmptyValues.length > 0.8) {
      return 'datetime';
    }

    return 'text';
  };

  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach(processFile);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'text/csv': ['.csv'],
      'text/plain': ['.txt']
    }
  });

  const removeFile = (fileId) => {
    setImportedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">数据导入</h2>
        
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
            isDragActive
              ? 'border-blue-400 bg-blue-50'
              : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          {isDragActive ? (
            <p className="text-blue-600">拖放文件到此处...</p>
          ) : (
            <div>
              <p className="text-gray-600 mb-2">拖拽文件到此处或点击选择文件</p>
              <p className="text-sm text-gray-500">支持格式: .xlsx, .xls, .csv, .txt</p>
            </div>
          )}
        </div>

        {Object.keys(uploadProgress).length > 0 && (
          <div className="mt-4 space-y-2">
            <h3 className="text-sm font-medium text-gray-900">上传进度</h3>
            {Object.entries(uploadProgress).map(([fileId, progress]) => (
              <div key={fileId} className="flex items-center space-x-2">
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="text-sm text-gray-600">{progress}%</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {importedFiles.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">导入历史</h3>
          <div className="space-y-3">
            {importedFiles.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-3">
                  <File className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{file.name}</p>
                    <div className="flex items-center space-x-2">
                      {file.status === 'success' ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className={`text-sm ${
                        file.status === 'success' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {file.message}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(file.id)}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  <X className="h-4 w-4 text-gray-400" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DataImport;
