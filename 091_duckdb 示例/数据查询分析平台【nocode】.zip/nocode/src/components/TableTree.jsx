import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Table, Hash, Type, Calendar } from 'lucide-react';

const TableTree = ({ tables, selectedTables, setSelectedTables }) => {
  const [expandedTables, setExpandedTables] = useState({});

  const toggleTable = (tableName) => {
    setExpandedTables(prev => ({
      ...prev,
      [tableName]: !prev[tableName]
    }));
  };

  const toggleTableSelection = (tableName) => {
    if (selectedTables.includes(tableName)) {
      setSelectedTables(prev => prev.filter(name => name !== tableName));
    } else {
      setSelectedTables(prev => [...prev, tableName]);
    }
  };

  const getFieldIcon = (dataType) => {
    switch (dataType?.toLowerCase()) {
      case 'integer':
      case 'float':
        return <Hash className="h-3 w-3 text-blue-500" />;
      case 'text':
      case 'string':
        return <Type className="h-3 w-3 text-green-500" />;
      case 'date':
      case 'datetime':
        return <Calendar className="h-3 w-3 text-purple-500" />;
      default:
        return <Type className="h-3 w-3 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-2">
      {tables.map((table) => (
        <div key={table.name} className="border border-gray-200 rounded-lg">
          <div className="flex items-center justify-between p-3 hover:bg-gray-50">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={selectedTables.includes(table.name)}
                onChange={() => toggleTableSelection(table.name)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <Table className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-900">{table.name}</span>
            </div>
            <button
              onClick={() => toggleTable(table.name)}
              className="p-1 hover:bg-gray-200 rounded"
            >
              {expandedTables[table.name] ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </button>
          </div>
          
          {expandedTables[table.name] && table.fields && (
            <div className="border-t border-gray-200 bg-gray-50">
              {table.fields.map((field, index) => (
                <div key={index} className="flex items-center space-x-2 px-6 py-2">
                  {getFieldIcon(field.type)}
                  <span className="text-sm text-gray-700">{field.name}</span>
                  <span className="text-xs text-gray-500">({field.type})</span>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default TableTree;
