import React from 'react';
import DataImport from './DataImport.jsx';
import TableManagement from './TableManagement.jsx';
import SqlQuery from './SqlQuery.jsx';
import QueryHistory from './QueryHistory.jsx';

const MainContent = ({ 
  activeTab, 
  selectedTables, 
  sqlQuery, 
  setSqlQuery, 
  queryResults, 
  setQueryResults 
}) => {
  const renderContent = () => {
    switch (activeTab) {
      case 'import':
        return <DataImport />;
      case 'tables':
        return <TableManagement />;
      case 'query':
        return (
          <SqlQuery 
            selectedTables={selectedTables}
            sqlQuery={sqlQuery}
            setSqlQuery={setSqlQuery}
            queryResults={queryResults}
            setQueryResults={setQueryResults}
          />
        );
      case 'history':
        return <QueryHistory />;
      default:
        return <DataImport />;
    }
  };

  return (
    <main className="flex-1 p-6">
      <div className="max-w-7xl mx-auto">
        {renderContent()}
      </div>
    </main>
  );
};

export default MainContent;
