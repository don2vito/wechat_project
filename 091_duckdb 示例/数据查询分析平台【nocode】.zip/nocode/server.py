#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据查询分析平台 - 后端服务器
使用Flask构建的RESTful API服务器
"""

import os
import json
import sqlite3
import pandas as pd
import duckdb
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime
import uuid

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

# 配置
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv', 'txt'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# 确保上传目录存在
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 内存中的数据存储
data_store = {}
query_history = []

def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_type(filename):
    """获取文件类型"""
    return filename.rsplit('.', 1)[1].lower()

def process_excel_file(filepath):
    """处理Excel文件"""
    try:
        df = pd.read_excel(filepath)
        return df_to_dict(df)
    except Exception as e:
        raise Exception(f"Excel文件处理失败: {str(e)}")

def process_csv_file(filepath):
    """处理CSV文件"""
    try:
        df = pd.read_csv(filepath)
        return df_to_dict(df)
    except Exception as e:
        raise Exception(f"CSV文件处理失败: {str(e)}")

def process_txt_file(filepath):
    """处理TXT文件"""
    try:
        df = pd.read_csv(filepath, sep='\t')
        return df_to_dict(df)
    except Exception as e:
        raise Exception(f"TXT文件处理失败: {str(e)}")

def df_to_dict(df):
    """将DataFrame转换为字典格式"""
    # 推断数据类型
    fields = []
    for col in df.columns:
        dtype = str(df[col].dtype)
        if dtype.startswith('int'):
            field_type = 'integer'
        elif dtype.startswith('float'):
            field_type = 'float'
        elif dtype.startswith('datetime'):
            field_type = 'datetime'
        else:
            field_type = 'text'
        
        fields.append({
            'name': col,
            'type': field_type
        })
    
    # 转换数据
    rows = []
    for _, row in df.iterrows():
        row_dict = {}
        for col in df.columns:
            value = row[col]
            if pd.isna(value):
                row_dict[col] = None
            else:
                row_dict[col] = value
        rows.append(row_dict)
    
    return {
        'fields': fields,
        'rows': rows,
        'rowCount': len(rows)
    }

@app.route('/')
def index():
    """返回前端页面"""
    return send_from_directory('.', 'index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """文件上传接口"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': '没有选择文件'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': '没有选择文件'}), 400
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_id = str(uuid.uuid4())
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{file_id}_{filename}")
            
            file.save(filepath)
            
            # 根据文件类型处理
            file_type = get_file_type(filename)
            if file_type in ['xlsx', 'xls']:
                data = process_excel_file(filepath)
            elif file_type == 'csv':
                data = process_csv_file(filepath)
            elif file_type == 'txt':
                data = process_txt_file(filepath)
            else:
                return jsonify({'error': '不支持的文件格式'}), 400
            
            # 存储数据
            table_name = filename.rsplit('.', 1)[0]
            data_store[table_name] = {
                'id': file_id,
                'name': table_name,
                'filename': filename,
                'filepath': filepath,
                'importTime': datetime.now().isoformat(),
                **data
            }
            
            return jsonify({
                'success': True,
                'table': data_store[table_name]
            })
        else:
            return jsonify({'error': '不支持的文件格式'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tables', methods=['GET'])
def get_tables():
    """获取所有数据表"""
    tables = list(data_store.values())
    return jsonify({'tables': tables})

@app.route('/api/tables/<table_name>', methods=['GET'])
def get_table(table_name):
    """获取指定数据表"""
    if table_name not in data_store:
        return jsonify({'error': '表不存在'}), 404
    
    return jsonify({'table': data_store[table_name]})

@app.route('/api/tables/<table_name>', methods=['DELETE'])
def delete_table(table_name):
    """删除数据表"""
    if table_name not in data_store:
        return jsonify({'error': '表不存在'}), 404
    
    # 删除文件
    table = data_store[table_name]
    if os.path.exists(table['filepath']):
        os.remove(table['filepath'])
    
    # 删除数据
    del data_store[table_name]
    
    return jsonify({'success': True})

@app.route('/api/query', methods=['POST'])
def execute_query():
    """执行SQL查询"""
    try:
        data = request.get_json()
        sql_query = data.get('query', '').strip()
        
        if not sql_query:
            return jsonify({'error': '查询语句不能为空'}), 400
        
        # 记录查询历史
        query_record = {
            'id': str(uuid.uuid4()),
            'query': sql_query,
            'timestamp': datetime.now().isoformat()
        }
        query_history.append(query_record)
        
        # 使用DuckDB执行查询
        conn = duckdb.connect(database=':memory:')
        
        # 注册所有表到DuckDB
        for table_name, table_data in data_store.items():
            df = pd.DataFrame(table_data['rows'])
            conn.register(table_name, df)
        
        # 执行查询
        result_df = conn.execute(sql_query).fetchdf()
        conn.close()
        
        # 转换结果
        result = df_to_dict(result_df)
        result['executionTime'] = '0.001s'  # 简化处理
        
        return jsonify({
            'success': True,
            'results': result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/query-history', methods=['GET'])
def get_query_history():
    """获取查询历史"""
    return jsonify({'history': query_history})

@app.route('/api/query-history/<query_id>', methods=['DELETE'])
def delete_query_history(query_id):
    """删除查询历史记录"""
    global query_history
    query_history = [q for q in query_history if q['id'] != query_id]
    return jsonify({'success': True})

@app.route('/api/export/<table_name>', methods=['GET'])
def export_table(table_name):
    """导出数据表"""
    if table_name not in data_store:
        return jsonify({'error': '表不存在'}), 404
    
    table = data_store[table_name]
    df = pd.DataFrame(table['rows'])
    
    # 创建导出文件
    export_filename = f"{table_name}_export.xlsx"
    export_path = os.path.join(app.config['UPLOAD_FOLDER'], export_filename)
    
    df.to_excel(export_path, index=False)
    
    return send_from_directory(app.config['UPLOAD_FOLDER'], export_filename, as_attachment=True)

if __name__ == '__main__':
    print("=" * 50)
    print("数据查询分析平台 - 后端服务器")
    print("=" * 50)
    print("服务器启动中...")
    print("访问地址: http://localhost:5000")
    print("=" * 50)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
