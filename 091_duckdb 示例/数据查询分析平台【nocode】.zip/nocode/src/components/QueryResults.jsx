import React, { useState } from 'react';
import { Download, ChevronLeft, ChevronRight, BarChart3 } from 'lucide-react';

const QueryResults = ({ results, onExport }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [pageSize, setPageSize] = useState(50);

  if (!results || !results.rows || results.rows.length === 0) {
    return null;
  }

  const sortedRows = React.useMemo(() => {
    if (!sortConfig.key) return results.rows;

    return [...results.rows].sort((a, b) => {
      const aVal = a[sortConfig.key];
      const bVal = b[sortConfig.key];

      if (aVal === bVal) return 0;
      
      const modifier = sortConfig.direction === 'asc' ? 1 : -1;
      
      if (aVal == null) return 1 * modifier;
      if (bVal == null) return -1 * modifier;
      
      // 尝试数值比较
      if (!isNaN(aVal) && !isNaN(bVal)) {
        return (parseFloat(aVal) - parseFloat(bVal)) * modifier;
      }
      
      // 字符串比较
      return String(aVal).localeCompare(String(bVal)) * modifier;
    });
  }, [results.rows, sortConfig]);

  const totalPages = Math.ceil(sortedRows.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentRows = sortedRows.slice(startIndex, endIndex);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  const formatCellValue = (value, fieldType) => {
    if (value == null || value === '') return '-';
    
    switch (fieldType?.toLowerCase()) {
      case 'datetime':
      case 'date':
        try {
          return new Date(value).toLocaleString('zh-CN');
        } catch {
          return value;
        }
      case 'float':
      case 'integer':
        return typeof value === 'number' ? value.toLocaleString('zh-CN') : value;
      default:
        return String(value);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <h3 className="text-lg font-medium text-gray-900">查询结果</h3>
          <span className="text-sm text-gray-500">
            共 {results.rowCount} 条记录，执行时间: {results.executionTime}
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={onExport}
            className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>导出CSV</span>
          </button>
          
          <button className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            <BarChart3 className="h-4 w-4" />
            <span>可视化</span>
          </button>
        </div>
      </div>

      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <label className="text-sm text-gray-700">每页显示:</label>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="border border-gray-300 rounded px-2 py-1 text-sm"
          >
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
            <option value={200}>200</option>
          </select>
        </div>
        
        <div className="text-sm text-gray-500">
          显示 {startIndex + 1}-{Math.min(endIndex, sortedRows.length)} 条，共 {sortedRows.length} 条
        </div>
      </div>

      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {results.fields.map((field) => (
                <th
                  key={field.name}
                  onClick={() => handleSort(field.name)}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-1">
                    <span>{field.name}</span>
                    <span className="text-gray-400">{getSortIcon(field.name)}</span>
                  </div>
                  <div className="text-xs text-gray-400 font-normal normal-case mt-1">
                    {field.type}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {currentRows.map((row, index) => (
              <tr key={index} className="hover:bg-gray-50">
                {results.fields.map((field) => (
                  <td
                    key={field.name}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-900"
                  >
                    <div className="max-w-xs truncate" title={row[field.name]}>
                      {formatCellValue(row[field.name], field.type)}
                    </div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="flex items-center space-x-1 px-3 py-2 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>上一页</span>
            </button>
            
            <span className="text-sm text-gray-700">
              第 {currentPage} 页，共 {totalPages} 页
            </span>
            
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="flex items-center space-x-1 px-3 py-2 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>下一页</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-700">跳转到:</span>
            <input
              type="number"
              min="1"
              max={totalPages}
              value={currentPage}
              onChange={(e) => {
                const page = parseInt(e.target.value);
                if (page >= 1 && page <= totalPages) {
                  setCurrentPage(page);
                }
              }}
              className="w-16 border border-gray-300 rounded px-2 py-1 text-sm"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default QueryResults;
