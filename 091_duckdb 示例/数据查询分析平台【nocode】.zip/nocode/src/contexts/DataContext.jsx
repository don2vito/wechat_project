import React, { createContext, useContext, useState } from 'react';

const DataContext = createContext();

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider = ({ children }) => {
  const [tables, setTables] = useState([]);
  const [importedFiles, setImportedFiles] = useState([]);
  const [fieldConfigs, setFieldConfigs] = useState({});
  const [queryHistory, setQueryHistory] = useState([]);

  const addTable = (table) => {
    setTables(prev => [...prev, table]);
  };

  const removeTable = (tableName) => {
    setTables(prev => prev.filter(table => table.name !== tableName));
    setFieldConfigs(prev => {
      const newConfigs = { ...prev };
      delete newConfigs[tableName];
      return newConfigs;
    });
  };

  const updateFieldConfig = (tableName, fieldName, config) => {
    setFieldConfigs(prev => ({
      ...prev,
      [tableName]: {
        ...prev[tableName],
        [fieldName]: config
      }
    }));
  };

  const addImportedFile = (file) => {
    setImportedFiles(prev => [...prev, file]);
  };

  const addQueryToHistory = (query) => {
    setQueryHistory(prev => [...prev, {
      id: Date.now(),
      query,
      timestamp: new Date().toISOString()
    }]);
  };

  const value = {
    tables,
    setTables,
    importedFiles,
    setImportedFiles,
    fieldConfigs,
    setFieldConfigs,
    queryHistory,
    setQueryHistory,
    addTable,
    removeTable,
    updateFieldConfig,
    addImportedFile,
    addQueryToHistory
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};
