import React, { useState } from 'react';
import { Table, Edit, Trash2, Eye, Download } from 'lucide-react';
import { useData } from '../contexts/DataContext.jsx';

const TableManagement = () => {
  const { tables, removeTable, fieldConfigs, updateFieldConfig } = useData();
  const [selectedTable, setSelectedTable] = useState(null);
  const [editingField, setEditingField] = useState(null);

  const dataTypeOptions = [
    { value: 'text', label: '文本' },
    { value: 'integer', label: '整数' },
    { value: 'float', label: '浮点数' },
    { value: 'date', label: '日期' },
    { value: 'datetime', label: '日期时间' }
  ];

  const handleFieldUpdate = (tableName, fieldName, newType) => {
    updateFieldConfig(tableName, fieldName, { type: newType });
    setEditingField(null);
  };

  const handleDeleteTable = (tableName) => {
    if (window.confirm(`确定要删除表 "${tableName}" 吗？此操作不可恢复。`)) {
      removeTable(tableName);
      if (selectedTable === tableName) {
        setSelectedTable(null);
      }
    }
  };

  const exportTable = (table) => {
    const csvContent = [
      table.fields.map(field => field.name).join(','),
      ...table.data.map(row => 
        table.fields.map(field => row[field.name] || '').join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${table.name}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">数据表管理</h2>
        
        {tables.length === 0 ? (
          <div className="text-center py-8">
            <Table className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-500">暂无数据表，请先导入数据</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tables.map((table) => (
              <div key={table.name} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-medium text-gray-900">{table.name}</h3>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedTable(selectedTable === table.name ? null : table.name)}
                      className="p-1 hover:bg-gray-100 rounded"
                      title="查看字段配置"
                    >
                      <Eye className="h-4 w-4 text-gray-500" />
                    </button>
                    <button
                      onClick={() => exportTable(table)}
                      className="p-1 hover:bg-gray-100 rounded"
                      title="导出数据"
                    >
                      <Download className="h-4 w-4 text-gray-500" />
                    </button>
                    <button
                      onClick={() => handleDeleteTable(table.name)}
                      className="p-1 hover:bg-gray-100 rounded"
                      title="删除表"
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">记录数:</span>
                    <span className="font-medium">{table.rowCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">字段数:</span>
                    <span className="font-medium">{table.fields.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">导入时间:</span>
                    <span className="font-medium">
                      {new Date(table.importTime).toLocaleString('zh-CN')}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedTable && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            字段配置 - {selectedTable}
          </h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    字段名
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    数据类型
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    预览数据
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    操作
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {tables.find(t => t.name === selectedTable)?.fields.map((field, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {field.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {editingField === field.name ? (
                        <select
                          value={field.type}
                          onChange={(e) => handleFieldUpdate(selectedTable, field.name, e.target.value)}
                          className="border border-gray-300 rounded px-2 py-1 text-sm"
                          autoFocus
                        >
                          {dataTypeOptions.map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {dataTypeOptions.find(opt => opt.value === field.type)?.label || field.type}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {tables.find(t => t.name === selectedTable)?.data.slice(0, 3).map((row, i) => (
                        <div key={i} className="truncate max-w-xs">
                          {row[field.name] || '-'}
                        </div>
                      ))}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => setEditingField(editingField === field.name ? null : field.name)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default TableManagement;
