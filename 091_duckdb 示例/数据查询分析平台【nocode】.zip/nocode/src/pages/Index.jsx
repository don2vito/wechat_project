import React, { useState } from 'react';
import Header from '../components/Header.jsx';
import Sidebar from '../components/Sidebar.jsx';
import MainContent from '../components/MainContent.jsx';
import { DataProvider } from '../contexts/DataContext.jsx';

const Index = () => {
  const [activeTab, setActiveTab] = useState('import');
  const [selectedTables, setSelectedTables] = useState([]);
  const [sqlQuery, setSqlQuery] = useState('');
  const [queryResults, setQueryResults] = useState(null);

  return (
    <DataProvider>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex">
          <Sidebar 
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            selectedTables={selectedTables}
            setSelectedTables={setSelectedTables}
          />
          <MainContent 
            activeTab={activeTab}
            selectedTables={selectedTables}
            sqlQuery={sqlQuery}
            setSqlQuery={setSqlQuery}
            queryResults={queryResults}
            setQueryResults={setQueryResults}
          />
        </div>
      </div>
    </DataProvider>
  );
};

export default Index;
