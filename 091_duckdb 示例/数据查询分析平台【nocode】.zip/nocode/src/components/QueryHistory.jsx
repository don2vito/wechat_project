import React, { useState } from 'react';
import { Clock, Play, Trash2, Search } from 'lucide-react';
import { useData } from '../contexts/DataContext.jsx';

const QueryHistory = () => {
  const { queryHistory } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuery, setSelectedQuery] = useState(null);

  const filteredHistory = queryHistory.filter(item =>
    item.query.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const executeQuery = (query) => {
    // 这里应该触发SQL查询执行
    console.log('执行查询:', query);
    // 可以通过回调函数或事件传递给父组件
  };

  const deleteQuery = (queryId) => {
    if (window.confirm('确定要删除这条查询记录吗？')) {
      // 这里应该从历史记录中删除
      console.log('删除查询:', queryId);
    }
  };

  const clearAllHistory = () => {
    if (window.confirm('确定要清空所有查询历史吗？此操作不可恢复。')) {
      // 这里应该清空所有历史记录
      console.log('清空查询历史');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">查询历史</h2>
          <button
            onClick={clearAllHistory}
            className="flex items-center space-x-2 px-3 py-2 text-sm bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>清空历史</span>
          </button>
        </div>

        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="搜索查询语句..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {filteredHistory.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-500">
              {searchTerm ? '没有找到匹配的查询记录' : '暂无查询历史'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredHistory.map((item) => (
              <div
                key={item.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-500">
                        {formatTimestamp(item.timestamp)}
                      </span>
                    </div>
                    
                    <div className="bg-gray-50 rounded p-3 mb-3">
                      <pre className="text-sm text-gray-800 whitespace-pre-wrap font-mono">
                        {item.query}
                      </pre>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <button
                      onClick={() => setSelectedQuery(item)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                      title="查看详情"
                    >
                      <Search className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => executeQuery(item.query)}
                      className="p-2 text-green-600 hover:bg-green-50 rounded"
                      title="重新执行"
                    >
                      <Play className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteQuery(item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded"
                      title="删除"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedQuery && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">查询详情</h3>
            <button
              onClick={() => setSelectedQuery(null)}
              className="text-gray-400 hover:text-gray-600"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                执行时间
              </label>
              <p className="text-sm text-gray-900">
                {formatTimestamp(selectedQuery.timestamp)}
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                SQL语句
              </label>
              <div className="bg-gray-50 rounded p-3">
                <pre className="text-sm text-gray-800 whitespace-pre-wrap font-mono">
                  {selectedQuery.query}
                </pre>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => executeQuery(selectedQuery.query)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                <Play className="h-4 w-4" />
                <span>重新执行</span>
              </button>
              
              <button
                onClick={() => {
                  navigator.clipboard.writeText(selectedQuery.query);
                  alert('SQL语句已复制到剪贴板');
                }}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
              >
                <span>复制语句</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QueryHistory;
