import React from 'react';
import { Database, User, Settings, LogOut } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-blue-600 text-white shadow-lg">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Database className="h-8 w-8" />
            <h1 className="text-xl font-bold">数据查询分析平台</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-blue-700 transition-colors">
              <User className="h-4 w-4" />
              <span>用户中心</span>
            </button>
            
            <button className="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-blue-700 transition-colors">
              <Settings className="h-4 w-4" />
              <span>设置</span>
            </button>
            
            <button className="flex items-center space-x-2 px-3 py-2 rounded-md hover:bg-blue-700 transition-colors">
              <LogOut className="h-4 w-4" />
              <span>退出</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
