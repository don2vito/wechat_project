import React from 'react';
import { Upload, Database, BarChart3, History, Table } from 'lucide-react';
import { useData } from '../contexts/DataContext.jsx';
import TableTree from './TableTree.jsx';

const Sidebar = ({ activeTab, setActiveTab, selectedTables, setSelectedTables }) => {
  const { tables } = useData();

  const menuItems = [
    { id: 'import', label: '数据导入', icon: Upload },
    { id: 'tables', label: '数据表管理', icon: Database },
    { id: 'query', label: 'SQL查询', icon: BarChart3 },
    { id: 'history', label: '查询历史', icon: History },
  ];

  return (
    <aside className="w-64 bg-white shadow-lg border-r border-gray-200">
      <div className="p-4">
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeTab === item.id
                    ? 'bg-blue-50 text-blue-600 border border-blue-200'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {activeTab === 'tables' && tables.length > 0 && (
        <div className="border-t border-gray-200 p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">已导入表格</h3>
          <TableTree 
            tables={tables}
            selectedTables={selectedTables}
            setSelectedTables={setSelectedTables}
          />
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
