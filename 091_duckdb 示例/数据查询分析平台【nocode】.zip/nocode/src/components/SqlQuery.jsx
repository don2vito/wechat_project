import React, { useState } from 'react';
import Editor from '@monaco-editor/react';
import { Play, Download, RotateCcw, Save } from 'lucide-react';
import { useData } from '../contexts/DataContext.jsx';
import QueryResults from './QueryResults.jsx';

const SqlQuery = ({ selectedTables, sqlQuery, setSqlQuery, queryResults, setQueryResults }) => {
  const { tables, addQueryToHistory } = useData();
  const [isExecuting, setIsExecuting] = useState(false);
  const [error, setError] = useState(null);

  const executeQuery = async () => {
    if (!sqlQuery.trim()) {
      setError('请输入SQL查询语句');
      return;
    }

    setIsExecuting(true);
    setError(null);

    try {
      // 模拟SQL查询执行
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 改进的查询解析和执行
      const results = simulateQuery(sqlQuery);
      setQueryResults(results);
      addQueryToHistory(sqlQuery);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setIsExecuting(false);
    }
  };

  const simulateQuery = (query) => {
    // 改进的查询模拟，支持中文表名
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('select') && lowerQuery.includes('from')) {
      // 查找表名，支持中文表名和引号
      const tableMatch = query.match(/from\s+["']?([^"'\s;]+)["']?/i);
      if (tableMatch) {
        const tableName = tableMatch[1];
        const table = tables.find(t => t.name === tableName);
        
        if (table) {
          // 简单的字段选择模拟
          const selectMatch = query.match(/select\s+(.*?)\s+from/i);
          let selectedFields = table.fields;
          
          if (selectMatch && selectMatch[1] !== '*') {
            const fieldNames = selectMatch[1].split(',').map(f => f.trim());
            selectedFields = table.fields.filter(f => 
              fieldNames.some(fn => fn.toLowerCase().includes(f.name.toLowerCase()))
            );
          }
          
          const rows = table.data.slice(0, 100).map(row => {
            const filteredRow = {};
            selectedFields.forEach(field => {
              filteredRow[field.name] = row[field.name];
            });
            return filteredRow;
          });
          
          return {
            fields: selectedFields,
            rows: rows,
            rowCount: rows.length,
            executionTime: '0.001s'
          };
        } else {
          throw new Error(`表 "${tableName}" 不存在`);
        }
      }
    }
    
    throw new Error('不支持的SQL语句');
  };

  const clearQuery = () => {
    setSqlQuery('');
    setQueryResults(null);
    setError(null);
  };

  const saveQuery = () => {
    if (sqlQuery.trim()) {
      localStorage.setItem('savedQuery', sqlQuery);
      alert('查询已保存');
    }
  };

  const loadSavedQuery = () => {
    const saved = localStorage.getItem('savedQuery');
    if (saved) {
      setSqlQuery(saved);
    }
  };

  const getSuggestions = () => {
    const suggestions = [];
    tables.forEach(table => {
      suggestions.push(`SELECT * FROM "${table.name}"`);
      table.fields.forEach(field => {
        suggestions.push(`SELECT "${field.name}" FROM "${table.name}"`);
      });
    });
    return suggestions;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">SQL查询编辑器</h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={loadSavedQuery}
              className="flex items-center space-x-2 px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
            >
              <Save className="h-4 w-4" />
              <span>加载保存的查询</span>
            </button>
          </div>
        </div>

        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-700">SQL查询语句</label>
            <div className="flex items-center space-x-2">
              <button
                onClick={clearQuery}
                className="flex items-center space-x-1 px-2 py-1 text-sm text-gray-600 hover:text-gray-800"
              >
                <RotateCcw className="h-3 w-3" />
                <span>清空</span>
              </button>
              <button
                onClick={saveQuery}
                className="flex items-center space-x-1 px-2 py-1 text-sm text-gray-600 hover:text-gray-800"
              >
                <Save className="h-3 w-3" />
                <span>保存</span>
              </button>
            </div>
          </div>
          
          <div className="border border-gray-300 rounded-lg overflow-hidden">
            <Editor
              height="200px"
              language="sql"
              value={sqlQuery}
              onChange={(value) => setSqlQuery(value || '')}
              options={{
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                fontSize: 14,
                lineNumbers: 'on',
                roundedSelection: false,
                cursorStyle: 'line',
                automaticLayout: true,
                suggestOnTriggerCharacters: true,
                quickSuggestions: true,
                wordBasedSuggestions: true
              }}
              theme="vs"
            />
          </div>
        </div>

        {selectedTables.length > 0 && (
          <div className="mb-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              已选择表: {selectedTables.map(table => `"${table}"`).join(', ')}
            </p>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={executeQuery}
              disabled={isExecuting || !sqlQuery.trim()}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Play className="h-4 w-4" />
              <span>{isExecuting ? '执行中...' : '执行查询'}</span>
            </button>
          </div>
          
          <div className="text-sm text-gray-500">
            提示: 选择左侧表格后，可以自动生成基础查询语句
          </div>
        </div>
      </div>

      {queryResults && (
        <QueryResults 
          results={queryResults}
          onExport={() => {
            // 导出功能实现
            const csvContent = [
              queryResults.fields.map(field => field.name).join(','),
              ...queryResults.rows.map(row => 
                queryResults.fields.map(field => row[field.name] || '').join(',')
              )
            ].join('\n');

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'query_results.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }}
        />
      )}
    </div>
  );
};

export default SqlQuery;
